[build-menu]
EX_00_LB=_Execute
EX_00_CM=lua "%f"
EX_00_WD=
